import os
import sys

if not "" in os.environ:
    raise RuntimeError("Required environment variable  does not exist! Please (re)install peak or provide the SDK root path of peak (<peak-Installation-Directory>/sdk/) manually via environment variable !")

if (sys.version_info[0] < 3) or ((sys.version_info[0] == 3) and (sys.version_info[1] < 8)):
    os.environ["Path"] = os.pathsep + os.path.join(os.environ[""], "api", "lib", "x86_32")
else:
    os.add_dll_directory(os.path.join(os.environ[""], "api", "lib", "x86_32"))
    # Workaround for Conda Python 3.8 environments under Windows. Although Python changed the DLL search mechanism in Python 3.8, Windows Conda Python 3.8 environments still use the old mechanism...
    os.environ["Path"] = os.pathsep + os.path.join(os.environ[""], "api", "lib", "x86_32")
